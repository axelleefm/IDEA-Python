# compliance_rule_1

This Ansible Role infuses antigravity, you are warned

## Usage

`ansible-galaxy install compliance_rule_1`

LICENSE: 3-clause BSD license.

## CONTRIBUTING

`git clone git@github.com:kecorbin/compliance_rule_1`

---
Copyright © 2014, Kevin Corbin
